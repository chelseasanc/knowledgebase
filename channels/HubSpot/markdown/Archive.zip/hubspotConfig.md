####How do I configure HubSpot?

1. From the dropdown menu on the HubSpot card, select “new configuration.” If you don’t see this menu, click the gear in the corner of the card to flip it over. 
2. Enter a name for this Channel configuration (e.g. “Azuqua HubSpot”).
3. [Log in to HubSpot.](https://login.hubspot.com/login/)
4. Find your API Key and paste it into the available field. 
<video></video>
5. Click “Save Configuration.”

Now, you can use this configuration every time you create a Flõ. You can also create multiple configurations for each channel to link all your accounts to Azuqua. [Read more about managing your configurations from the Settings page.]()